-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 07/08/2021 às 01:37
-- Versão do servidor: 5.7.35-cll-lve
-- Versão do PHP: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `eletivas_central`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `checklist`
--

CREATE TABLE `checklist` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` text COLLATE utf8mb4_unicode_ci,
  `dataSolicitacao` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cns` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idade` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sexo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cpf` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rg` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `orgaoEmissor` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `diagnostico` text COLLATE utf8mb4_unicode_ci,
  `macroOrigem` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hospitalOrigem` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `LeitoOrigem` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `macroDestino` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hospitalDestino` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `LeitoDestino` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `padrao` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contato` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `respiratoria` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `covid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metodo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` date DEFAULT NULL,
  `sng` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `svd` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dreno` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tottqd` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gtt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pai` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kehr` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acessoVenosoCentral` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acessoVenosoPeriferico` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cateterDialise` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dve` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `outros` text COLLATE utf8mb4_unicode_ci,
  `drogas` text COLLATE utf8mb4_unicode_ci,
  `suporteo2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cateter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mascara` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `outroSu` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vm` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fiO2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `peep` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `spO2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prona` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `risco` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aguda` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `funcionalidade` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `spo2c` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `temp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `peso` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `altura` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `outrosIC` text COLLATE utf8mb4_unicode_ci,
  `comorbidades` text COLLATE utf8mb4_unicode_ci,
  `nir` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `regulador` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usuario` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `checklist`
--

INSERT INTO `checklist` (`id`, `nome`, `dataSolicitacao`, `cns`, `dn`, `idade`, `sexo`, `cpf`, `rg`, `orgaoEmissor`, `estado`, `diagnostico`, `macroOrigem`, `hospitalOrigem`, `LeitoOrigem`, `macroDestino`, `hospitalDestino`, `LeitoDestino`, `padrao`, `contato`, `respiratoria`, `covid`, `metodo`, `data`, `sng`, `svd`, `dreno`, `tottqd`, `gtt`, `pai`, `kehr`, `acessoVenosoCentral`, `acessoVenosoPeriferico`, `cateterDialise`, `dve`, `outros`, `drogas`, `suporteo2`, `cateter`, `mascara`, `outroSu`, `vm`, `fiO2`, `peep`, `spO2`, `prona`, `risco`, `aguda`, `funcionalidade`, `pa`, `fc`, `spo2c`, `temp`, `peso`, `altura`, `outrosIC`, `comorbidades`, `nir`, `regulador`, `usuario`, `created_at`, `updated_at`) VALUES
(1, 'Nome completo', '2021-08-19', '15166645897897', '13231321544897', '55', 'Masculino', '00000005585444', '12314564879746', 'Secretaria de segurança publica', 'Santa de Catarina', 'What is Lorem Ipsum?\r\nLorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'Macro Sul', 'Hospital Tubarao', '21', 'Macro Florianopolis', 'Hospital de Florianopolis', '66', 'Sim', 'Não', 'Sim', 'Supeito', 'PCR', '2021-08-18', 'SNG', 'SVD', 'Dreno', 'TOT/TQT', 'GTT', 'Pai', 'kehr', 'Acesso Venoso Central', 'Acesso Venoso Periférico', 'Cateter Dialise', 'DVE', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'Sim', 'Cateter', 'Mascara Reservatório', 'Outros', 'Sim', 'FiO2', 'PEEP', 'SPO2', 'Prona', 'Sim', 'Sim', 'Ecog', 'PA', 'FC', 'Spo2', 'temp', 'Peso', 'Altura', 'Outros', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'Médico / Assistente / Nir', 'Médico Regulador', 'andregds85@gmail.com', '2021-08-05 20:22:34', '2021-08-05 20:22:34');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `checklist`
--
ALTER TABLE `checklist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `checklist`
--
ALTER TABLE `checklist`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
